FF MAX OB55 Panel — Android project

IMPORTANT:
Yeh safe practice/settings helper hai. Yeh Free Fire MAX ko modify ya control nahi karta.
Ismein aimbot, ESP cheat, anti-ban bypass, memory editing ya game files ka access nahi hai.

APK banane ka aasaan tareeqa (Android mobile se):
1. ZIP ko extract karo.
2. GitHub par nayi repository banao.
3. Is folder ke saare files repository mein upload karo.
4. Repository ke Actions tab mein jao.
5. "Build Android APK" workflow kholo aur "Run workflow" dabao.
6. Build complete hone par Artifacts mein FF-MAX-OB55-Panel-debug download karo.
7. ZIP extract karke app-debug.apk ko Android par install karo.
   Android settings mein browser/file manager ke liye "Install unknown apps" permission deni pad sakti hai.

Agar GitHub Actions workflow pehli baar enable karna kahe, enable karke dobara Run workflow karo.
