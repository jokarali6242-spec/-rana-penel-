package com.gtrana.ob55panel;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int bg = Color.rgb(13, 14, 20), panel = Color.rgb(27, 29, 39), red = Color.rgb(255, 55, 75);
    LinearLayout page;

    GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    void gap(int h) { View v = new View(this); page.addView(v, new LinearLayout.LayoutParams(1,h)); }
    void section(String title) {
        TextView t = text(title, 17, Color.WHITE, true);
        t.setPadding(0, 18, 0, 8); page.addView(t);
    }
    void toggle(String title, String subtitle) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(14, 12, 12, 12); row.setBackground(shape(panel, 18));
        LinearLayout words = new LinearLayout(this); words.setOrientation(1);
        words.addView(text(title, 15, Color.WHITE, true));
        words.addView(text(subtitle, 11, Color.LTGRAY, false));
        row.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this); sw.setChecked(false);
        sw.setOnCheckedChangeListener((b, checked) ->
            Toast.makeText(this, checked ? "Practice setting enabled" : "Setting disabled", Toast.LENGTH_SHORT).show());
        row.addView(sw); page.addView(row);
        gap(9);
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        page = new LinearLayout(this); page.setOrientation(1); page.setPadding(18, 24, 18, 28);
        scroll.addView(page); setContentView(scroll);

        TextView brand = text("FF MAX  •  OB55", 13, red, true); page.addView(brand);
        TextView title = text("GAMING CONTROL PANEL", 25, Color.WHITE, true); page.addView(title);
        TextView desc = text("Practice tools & device settings", 13, Color.LTGRAY, false); page.addView(desc);
        gap(18);

        LinearLayout notice = new LinearLayout(this); notice.setOrientation(1);
        notice.setPadding(15, 14, 15, 14); notice.setBackground(shape(Color.rgb(55,35,38), 16));
        notice.addView(text("SAFE PRACTICE MODE", 14, Color.rgb(255,130,140), true));
        notice.addView(text("This app does not connect to Free Fire MAX or provide cheats, aimbot, ESP, or anti-ban bypass.", 12, Color.WHITE, false));
        page.addView(notice);

        section("AIM & TRAINING");
        toggle("Aim practice reminder", "Reminder to practice tracking and flick aim");
        toggle("Headshot drill", "Use in-game training ground exercises");
        toggle("Crosshair focus", "On-screen practice checklist only");

        section("GAMEPLAY SETUP");
        toggle("Custom HUD checklist", "Remember your preferred button layout");
        toggle("Sensitivity notes", "Keep your sensitivity settings handy");
        toggle("Performance mode", "Closes nothing; shows device optimization tips");

        section("DEVICE TIPS");
        TextView tip = text("For smoother gameplay: close unused apps, keep your phone cool, use a stable network, and adjust graphics inside the official game settings.", 13, Color.WHITE, false);
        tip.setPadding(14,14,14,14); tip.setBackground(shape(panel,18)); page.addView(tip);
        gap(18);
        TextView footer = text("Made for Android • Unofficial fan utility • Not affiliated with Garena", 10, Color.GRAY, false);
        footer.setGravity(Gravity.CENTER); page.addView(footer);
    }
}
